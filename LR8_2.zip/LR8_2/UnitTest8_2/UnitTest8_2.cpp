#include "pch.h"
#include "CppUnitTest.h"
#include "..\LR8_2\LR8_2.cpp"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest82
{
	TEST_CLASS(UnitTest82)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
            string input1 = "Hello World";
            int expectedOutput1 = 2;
            Assert::AreEqual(CountWords(input1), expectedOutput1);

            string input2 = " This is a test ";
            int expectedOutput2 = 4;
            Assert::AreEqual(CountWords(input2), expectedOutput2);

            string input3 = "Create unit test ";
            int expectedOutput3 = 3;
            Assert::AreEqual(CountWords(input3), expectedOutput3);

            string input4 = " ";
            int expectedOutput4 = 0;
            Assert::AreEqual(CountWords(input4), expectedOutput4);

            string input5 = "OneWord";
            int expectedOutput5 = 1;
            Assert::AreEqual(CountWords(input5), expectedOutput5);
		}
	};
}
